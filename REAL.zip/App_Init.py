import os
import sys
import subprocess
import psutil
from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtWidgets import QApplication, QMainWindow, QFileDialog, QListWidgetItem, QLineEdit, QWidget, QGraphicsScene, QGraphicsEllipseItem
from PyQt5.uic import loadUi 
from PyQt5.QtCore import QTimer, Qt, QMetaObject, QProcess
from PyQt5.QtGui import QImage, QPixmap, QCursor, QPainter, QColor, QPen, QBrush

import mediapipe as mp
import autopy
from HandTrackingModule import HandDetector
from tensorflow.keras.models import load_model
from Server_Control import Server, Control
from Network_Packet import PacketTag, Packet
from App_Help import Active_Help

import icon_toolbar
import icon_gesture

import cv2
import threading
import keyboard
import webbrowser
import time
import pyautogui
import zlib
import base64
import shutil
from PIL import Image

class Init_Menu(QMainWindow):
    def __init__(self):
        super().__init__()

        # UI 관련
        loadUi("Init_Menu.ui", self)      # UI 파일 로드
        self.setWindowTitle("Start")

        # 웹캠 객체
        self.cap = cv2.VideoCapture(0)
        self.hand_detector = HandDetector()
        self.help_active = Active_Help()

        self.actions = ['STANDARD', 'MAP', 'MEDIA', 'SERVER']
        self.action = ''

        self.is_running = True
        self.standard_count = True
        self.map_count = True
        self.media_count = True
        self.server_count= True

         # 최상단 UI 버튼 이벤트 연결
        self.actionWindow_Capture.triggered.connect(self.capture_tool)
        self.actionNotepad.triggered.connect(self.notepad_tool)

        self.actionNaver_Map.triggered.connect(self.open_naver_button)
        self.actionDaum_Map.triggered.connect(self.open_daum_button)
        self.actionGoogle_Map.triggered.connect(self.open_google_button)

        self.actionProgram_Close_2.triggered.connect(self.stop_program)

        # 상단 UI 버튼 이벤트 연결
        self.action_Capture.triggered.connect(self.capture_tool)
        self.action_Notepad.triggered.connect(self.notepad_tool)
        self.action_help.triggered.connect(self.help_button)

        # 버튼 클릭
        self.push_button1.clicked.connect(self.create_standard_instance)
        self.push_button2.clicked.connect(self.create_map_instance)
        self.push_button3.clicked.connect(self.create_media_instance)
        self.push_button4.clicked.connect(self.create_server_instance)
        self.push_button5.clicked.connect(self.stop_program)

    #     thread = threading.Thread(target=self.Read_Frame_Init)
    #     thread.daemon = True
    #     thread.start()

    # def Read_Frame_Init(self):
    #     seq = []
    #     action_seq = []
    #     # 4개의 제스쳐 (MOVE, CLICK, NEXT)만 학습된 모델을 불러와야한다.
    #     model = load_model('models/model_Init.h5')

    #     while self.is_running:
    #         ret, frame = self.cap.read()                                        # 웹캠 프레임 읽기
    #         frame = cv2.flip(frame, 1)                                      # 웹캠 좌우 반전
    #         frame = self.hand_detector.find_hands(frame)
    #         lm_list, label = self.hand_detector.find_positions(frame)
    #         self.action = self.hand_detector.action_estimation(frame, seq, action_seq, model, self.actions)

    #         if lm_list:

    #             # 4가지 액션에 대해 분리
    #             if self.action == 'STANDARD':
    #                 if self.standard_count:
    #                     QMetaObject.invokeMethod(self, "create_standard_instance", Qt.QueuedConnection)


    #         else:
    #             self.action = '?'


    #         # 프레임 화면에 출력
    #         rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # BGR을 RGB로 변환
    #         h, w, ch = rgb_frame.shape
    #         bytes_per_line = ch * w 
    #         q_img = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
    #         q_pixmap = QPixmap.fromImage(q_img)
    #         self.Webcam_label1.setPixmap(q_pixmap) 
    
    def create_standard_instance(self):
        self.app_standard = Standard(self.cap)
        self.app_standard.show()

    def create_map_instance(self):
        self.app_map = Map(self.cap)
        self.app_map.show()

    def create_media_instance(self):
        self.app_media = Media(self.cap)
        self.app_media.show()

    def create_server_instance(self):
        self.app_server = Server_Menu(self.cap)
        self.app_server.show()

    # 종료 UI 버튼
    def stop_program(self):
        QApplication.quit()

    # 상단 UI - toolbar 버튼
    def capture_tool(self):
        capture_tool_path = "C:\windows\system32\SnippingTool.exe"

        capture_process = QProcess(self)
        capture_process.startDetached(capture_tool_path)

    def notepad_tool(self):
        notepad_tool_path = "notepad.exe"

        notepad_process = QProcess(self)
        notepad_process.startDetached(notepad_tool_path)

    def help_button(self):
        self.help_active.show()

    # Map 버튼
    def open_naver_button(self):
        webbrowser.open('https://map.naver.com/', new=2)

    def open_daum_button(self):
        webbrowser.open('https://map.kakao.com/', new=2)

    def open_google_button(self):
        webbrowser.open('https://www.google.co.kr/maps/', new=2)




class Standard(QMainWindow):
    def __init__(self, cap):
        super().__init__()

        # UI 관련
        loadUi("Standard.ui", self)      # UI 파일 로드
        self.setWindowTitle("시작 화면 ( 마우스 간단한 기능 )") 
        self.setGeometry(700, 300, 1200, 580)
        
        self.cap = cap

        self.hand_detector = HandDetector()

        self.actions = ['MOVE', 'CLICK', 'NEXT']
        self.action = ''

        # 선택 스크롤에 기능 선택
        Scroll_items = ['MOVE', 'CLICK', 'NEXT']

        # comboBox들을 리스트로 저장
        comboboxes = [self.comboBox2_1, self.comboBox2_2, self.comboBox2_3]

        for index, Scroll_item in enumerate(Scroll_items):
            # 각각의 comboBox에 아이템 추가
            if index < len(comboboxes):
                comboboxes[index].addItem(Scroll_item)

        for Scroll_item in Scroll_items:
            self.comboBox2_1.addItem(Scroll_item)
            self.comboBox2_2.addItem(Scroll_item)
            self.comboBox2_3.addItem(Scroll_item)

        # 적용 버튼
        self.gesture_push_button.clicked.connect(self.gesture_update)

        # 원 그래픽
        self.circle1 = QGraphicsEllipseItem(0, 0, 50, 50)
        self.circle1.setBrush(QBrush(QColor(255, 0, 0)))
        self.circle1.setFlag(self.circle1.ItemIsMovable)

        # graphicsView -> QGraphicsScene 연동
        self.graphicsView.setScene(QGraphicsScene())

        self.graphicsView.scene().addItem(self.circle1)

        self.graphicsView.setMouseTracking(True)  # Enable mouse tracking

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_circle_positions)
        self.timer.start(1000 / 60)  # 60 FPS

        self.is_running = True
        
        thread = threading.Thread(target=self.Read_Frame_Standard)
        thread.daemon = True
        thread.start()

            
    def update_circle_positions(self):
        pos1 = self.graphicsView.mapToScene(self.mapFromGlobal(self.cursor().pos()))
        self.circle1.setPos(pos1)

    def Read_Frame_Standard(self):
        seq = []
        action_seq = []
        # 원하는 제스쳐가 학습된 정확한 모델을 불러와야 한다
        model = load_model('models/model_standard.h5')   

        while self.is_running:
            ret, frame = self.cap.read()                                        # 웹캠 프레임 읽기
            frame = cv2.flip(frame, 1)                                      # 웹캠 좌우 반전
            frame = self.hand_detector.find_hands(frame)
            lm_list, label = self.hand_detector.find_positions(frame)
            self.action = self.hand_detector.action_estimation(frame, seq, action_seq, model, self.actions)

            if lm_list:

                # 3가지 액션에 따라 동작 분리
                if self.action == 'MOVE':
                    self.circle1.setBrush(QBrush(QColor(255,0,0)))
                    size_x, size_y = autopy.screen.size()
                    
                    x = int(lm_list[9][1] * size_x / 620)          # x좌표 스케일링
                    y = int(lm_list[9][2] * size_y / 360)          # y좌표 스케일링
                    x = min(size_x - 1, max(0, x))        # x좌표 제한
                    y = min(size_y - 1, max(0, y))        # y좌표 제한

                    # 마우스 움직임
                    cursor = QCursor()
                    self.cursor().setPos(x, y)


                elif self.action == 'CLICK':
                    self.circle1.setBrush(QBrush(QColor(0,0,255)))

                elif self.action == 'NEXT':
                    self.is_running = False
                    Init_Menu.is_running = True
                    break

            # 프레임 화면에 출력
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # BGR을 RGB로 변환
            h, w, ch = rgb_frame.shape
            bytes_per_line = ch * w 
            q_img = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
            q_pixmap = QPixmap.fromImage(q_img)
            self.Webcam_label1.setPixmap(q_pixmap) 

        if not self.is_running:
            # while문은 다음 화면으로 넘어갈때만 멈춘다.
            self.hide()
            

    def gesture_update(self):
        self.actions.clear()
        self.actions.append(self.comboBox2_1.currentText())
        self.actions.append(self.comboBox2_2.currentText())
        self.actions.append(self.comboBox2_3.currentText())

class Map(QMainWindow):
    def __init__(self, cap):
        super().__init__()

        # UI 관련
        loadUi("UI_Mode_Map.ui", self)      # UI 파일 로드
        self.setWindowTitle("Map 조작 모드") 
        self.setGeometry(1400, 76, 520, 927)

        self.cap = cap

        self.hand_detector = HandDetector()
        self.is_running = True

        self.actions = ['UP', 'DOWN', 'RIGHT', 'LEFT', 'ZOOM_IN', 'ZOOM_OUT', 'NEXT']
        self.action = ''

        # 선택 스크롤에 기능 선택
        Scroll_items = ['UP', 'DOWN', 'RIGHT', 'LEFT', 'ZOOM_IN', 'ZOOM_OUT', 'NEXT']

        # comboBox들을 리스트로 저장
        comboboxes = [self.comboBox2_1, self.comboBox2_2, self.comboBox2_3, self.comboBox2_4, self.comboBox2_5, self.comboBox2_6, self.comboBox2_7]

        for index, Scroll_item in enumerate(Scroll_items):
            # 각각의 comboBox에 아이템 추가
            if index < len(comboboxes):
                comboboxes[index].addItem(Scroll_item)

        for Scroll_item in Scroll_items:
            self.comboBox2_1.addItem(Scroll_item)
            self.comboBox2_2.addItem(Scroll_item)
            self.comboBox2_3.addItem(Scroll_item)
            self.comboBox2_4.addItem(Scroll_item)
            self.comboBox2_5.addItem(Scroll_item)
            self.comboBox2_6.addItem(Scroll_item)
            self.comboBox2_7.addItem(Scroll_item)

        # 적용 버튼
        self.gesture_pushbutton_2.clicked.connect(self.gesture_update)

        thread = threading.Thread(target=self.Read_Frame_Map)
        thread.daemon = True
        thread.start()
        
        # 생성되었을 때 카카오맵 실행 및 오른쪽 최상단에 고정
        webbrowser.open('https://map.kakao.com/')

        # Always On Top 설정
        if sys.platform == 'win32':  # Windows 운영체제인 경우
            self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

    def gesture_update(self):
        self.actions.clear()
        self.actions.append(self.comboBox2_1.currentText())
        self.actions.append(self.comboBox2_2.currentText())
        self.actions.append(self.comboBox2_3.currentText())
        self.actions.append(self.comboBox2_4.currentText())
        self.actions.append(self.comboBox2_5.currentText())
        self.actions.append(self.comboBox2_6.currentText())
        self.actions.append(self.comboBox2_7.currentText())

    def Read_Frame_Map(self):
        seq = []
        action_seq = []
        # 원하는 제스쳐가 학습된 정확한 모델을 불러와야 한다
        model = load_model('models/model_map.h5')   

        while self.is_running:
            ret, frame = self.cap.read()                                        # 웹캠 프레임 읽기
            frame = cv2.flip(frame, 1)                                      # 웹캠 좌우 반전
            frame = self.hand_detector.find_hands(frame)
            lm_list, label = self.hand_detector.find_positions(frame)
            self.action = self.hand_detector.action_estimation(frame, seq, action_seq, model, self.actions)

            if lm_list:
                if self.action == 'UP':
                    print('UP')
                    keyboard.press_and_release('up')

                elif self.action == 'DOWN':
                    print('DOWN')
                    keyboard.press_and_release('down')
                    
                elif self.action == 'RIGHT':
                    print('RIGHT')
                    keyboard.press_and_release('right')

                elif self.action == 'LEFT':
                    print('LEFT')
                    keyboard.press_and_release('left')

                elif self.action == 'ZOOM_IN':
                    print('ZOOM_IN')
                    keyboard.press_and_release('+')

                elif self.action == 'ZOOM_OUT':
                    print('ZOOM_OUT')
                    keyboard.press_and_release('-')

                elif self.action == 'NEXT':
                    self.is_running = False
                    Init_Menu.is_running = True
                    break
                
                    

            # 프레임 화면에 출력
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # BGR을 RGB로 변환
            h, w, ch = rgb_frame.shape
            bytes_per_line = ch * w 
            q_img = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
            q_pixmap = QPixmap.fromImage(q_img)
            self.Webcam_label1.setPixmap(q_pixmap) 

        if not self.is_running:
            # while문은 다음 화면으로 넘어갈때만 멈춘다.
            self.hide()

class Media(QMainWindow):
    def __init__(self, cap):
        super().__init__()

        # UI 관련
        loadUi("UI_Mode_Media.ui", self)      # UI 파일 로드
        self.setWindowTitle("Media 조작 모드") 
        self.setGeometry(1400, 76, 520, 927)

        self.cap = cap

        self.hand_detector = HandDetector()
        self.is_running = True

        self.actions = ['UP', 'DOWN', 'FORWARD', 'BACKWARD', 'PLAY_STOP', 'FULL_NORMAL', 'NEXT']
        self.action = ''

        # 선택 스크롤에 기능 선택
        Scroll_items = ['UP', 'DOWN', 'FORWARD', 'BACKWARD', 'PLAY_STOP', 'FULL_NORMAL', 'NEXT']

        # comboBox들을 리스트로 저장
        comboboxes = [self.comboBox2_1, self.comboBox2_2, self.comboBox2_3, self.comboBox2_4, self.comboBox2_5, self.comboBox2_6, self.comboBox2_7]

        for index, Scroll_item in enumerate(Scroll_items):
            # 각각의 comboBox에 아이템 추가
            if index < len(comboboxes):
                comboboxes[index].addItem(Scroll_item)

        for Scroll_item in Scroll_items:
            self.comboBox2_1.addItem(Scroll_item)
            self.comboBox2_2.addItem(Scroll_item)
            self.comboBox2_3.addItem(Scroll_item)
            self.comboBox2_4.addItem(Scroll_item)
            self.comboBox2_5.addItem(Scroll_item)
            self.comboBox2_6.addItem(Scroll_item)
            self.comboBox2_7.addItem(Scroll_item)
            
        # 적용 버튼
        self.gesture_pushbutton_2.clicked.connect(self.gesture_update)

        self.up_flag = True
        self.down_flag = True
        self.forward_flag = True
        self.backward_flag = True
        self.play_stop_flag = True
        self.full_normal_flag = True

        thread = threading.Thread(target=self.Read_Frame_Media)
        thread.daemon = True
        thread.start()

         # 생성되었을 때 유튜브 실행 및 오른쪽 최상단에 고정
        webbrowser.open('https://www.youtube.com/')

        # Always On Top 설정
        if sys.platform == 'win32':  # Windows 운영체제인 경우
            self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)

    def gesture_update(self):
        self.actions.clear()
        self.actions.append(self.comboBox2_1.currentText())
        self.actions.append(self.comboBox2_2.currentText())
        self.actions.append(self.comboBox2_3.currentText())
        self.actions.append(self.comboBox2_4.currentText())
        self.actions.append(self.comboBox2_5.currentText())
        self.actions.append(self.comboBox2_6.currentText())
        self.actions.append(self.comboBox2_7.currentText())

    def Read_Frame_Media(self):
        seq = []
        action_seq = []
        # 원하는 제스쳐가 학습된 정확한 모델을 불러와야 한다
        model = load_model('models/model_media.h5')   

        # 문제점 : 텀을 두고 동작하게 해야할듯 조정이 필요하다

        while self.is_running:
            ret, frame = self.cap.read()                                        # 웹캠 프레임 읽기
            frame = cv2.flip(frame, 1)                                      # 웹캠 좌우 반전
            frame = self.hand_detector.find_hands(frame)
            lm_list, label = self.hand_detector.find_positions(frame)
            self.action = self.hand_detector.action_estimation(frame, seq, action_seq, model, self.actions)

            if lm_list:
                if self.action == 'UP':
                    if self.up_flag:
                        print('UP')
                        keyboard.press_and_release('up')
                        self.up_flag = False

                elif self.action == 'DOWN':
                    if self.down_flag:
                        print('DOWN')
                        keyboard.press_and_release('down')
                        self.up_flag = False

                elif self.action == 'FORWARD':
                    if self.forward_flag:
                        print('FORWARD')
                        keyboard.press_and_release('right')
                        self.up_flag = False

                elif self.action == 'BACKWARD':
                    if self.backward_flag:
                        print('BACKWARD')
                        keyboard.press_and_release('left')
                        self.up_flag = False

                elif self.action == 'PLAY_STOP':
                    if self.play_stop_flag:
                        print('PLAY_STOP')
                        keyboard.press_and_release('space')
                        self.up_flag = False
                elif self.action == 'FULL_NORMAL':
                   if self.full_normal_flag:
                        print('FULL_NORMAL')
                        keyboard.press_and_release('f')
                        self.up_flag = False

                elif self.action == 'NEXT':
                    self.is_running = False
                    Init_Menu.is_running = True
                    break

            elif not lm_list:
                self.up_flag = True
                self.down_flag = True
                self.forward_flag = True
                self.backward_flag = True
                self.play_stop_flag = True
                self.full_normal_flag = True
        

            # 프레임 화면에 출력
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # BGR을 RGB로 변환
            h, w, ch = rgb_frame.shape
            bytes_per_line = ch * w 
            q_img = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
            q_pixmap = QPixmap.fromImage(q_img)
            self.Webcam_label1.setPixmap(q_pixmap) 

        if not self.is_running:
            # while문은 다음 화면으로 넘어갈때만 멈춘다.
            self.hide()

class Server_Menu(QMainWindow):
    def __init__(self, cap):
        super().__init__()

        # UI 관련
        loadUi("UI_Mode_Server.ui", self)      # UI 파일 로드
        self.setWindowTitle("Server 조작 모드") 
        self.setGeometry(1400, 76, 1510, 890)

        self.cap = cap

        self.hand_detector = HandDetector()
        self.is_running = True
        self.screen_share = True
        self.requset_screen = True
        self.folder = True
        self.send = True

        self.user_list = []
        self.dataset = None

        self.actions = ['SHARE_START', 'SHARE_STOP', 'REQUEST_START', 'REQUEST_STOP', 'OPEN_FOLDER', 'FILE_SEND', 'NEXT']
        self.action = ''

        # 선택 스크롤에 기능 선택
        Scroll_items = ['SHARE_START', 'SHARE_STOP', 'REQUEST_START', 'REQUEST_STOP', 'OPEN_FOLDER', 'FILE_SEND', 'NEXT']

        # comboBox들을 리스트로 저장
        comboboxes = [self.comboBox2_1, self.comboBox2_2, self.comboBox2_3, self.comboBox2_4, self.comboBox2_5, self.comboBox2_6, self.comboBox2_7]

        for index, Scroll_item in enumerate(Scroll_items):
            # 각각의 comboBox에 아이템 추가
            if index < len(comboboxes):
                comboboxes[index].addItem(Scroll_item)

        for Scroll_item in Scroll_items:
            self.comboBox2_1.addItem(Scroll_item)
            self.comboBox2_2.addItem(Scroll_item)
            self.comboBox2_3.addItem(Scroll_item)
            self.comboBox2_4.addItem(Scroll_item)
            self.comboBox2_5.addItem(Scroll_item)
            self.comboBox2_6.addItem(Scroll_item)
            self.comboBox2_7.addItem(Scroll_item)
            
        # 적용 버튼
        self.gesture_pushbutton_2.clicked.connect(self.gesture_update)

        # 공유받을 화면 버튼
        self.user_screen_recive.clicked.connect(self.request_screen_start)
        self.user_screen_recive_stop.clicked.connect(self.requset_screen_stop)

        # 파일 선택/전송 버튼
        self.file_select_Button.clicked.connect(self.select_file)
        self.file_send_Button.clicked.connect(self.file_send)

        # 파일 리스트 위젯 초기화 ( Downloads 폴더의 모든 파일들을 위젯에 추가 )
        self.file_widget_Item_add()

        thread = threading.Thread(target=self.Read_Frame_Server)
        thread.daemon = True
        thread.start()

        self.server = None

        server_thread = threading.Thread(target=self.run_server)
        server_thread.daemon = True
        server_thread.start()

    def gesture_update(self):
        self.actions.clear()
        self.actions.append(self.comboBox2_1.currentText())
        self.actions.append(self.comboBox2_2.currentText())
        self.actions.append(self.comboBox2_3.currentText())
        self.actions.append(self.comboBox2_4.currentText())
        self.actions.append(self.comboBox2_5.currentText())
        self.actions.append(self.comboBox2_6.currentText())
        self.actions.append(self.comboBox2_7.currentText())
        
    def eventFilter(self, source, event):
        if (event.type() == QtCore.QEvent.KeyPress and source is self.text_chatting1):
            if event.key() == QtCore.Qt.Key_Return or event.key() == QtCore.Qt.Key_Enter:
                self.short_message()
                return True
        return super().eventFilter(source, event)

    def Read_Frame_Server(self):
        seq = []
        action_seq = []
        # 원하는 제스쳐가 학습된 정확한 모델을 불러와야 한다
        model = load_model('models/model_map.h5')   

        while self.is_running:
            ret, frame = self.cap.read()                                        # 웹캠 프레임 읽기
            frame = cv2.flip(frame, 1)                                      # 웹캠 좌우 반전
            frame = self.hand_detector.find_hands(frame)
            lm_list, label = self.hand_detector.find_positions(frame)
            self.action = self.hand_detector.action_estimation(frame, seq, action_seq, model, self.actions)

            if lm_list:
                if self.action == 'SHARE_START':
                    if self.screen_share:
                        self.screen_share_start()

                elif self.action == 'SHARE_STOP':
                    if not self.screen_share:
                        self.screen_share_stop()

                elif self.action == 'REQUEST_START':
                    if self.requset_screen:
                        self.request_screen_start()

                elif self.action == 'REQUEST_STOP':
                    if not self.requset_screen:
                        self.requset_screen_stop()

                elif self.action == 'OPEN_FOLDER':
                    if self.folder:
                        self.open_folder()

                elif self.action == 'FILE_SEND':
                    if self.send:
                        self.file_send()

                elif self.action == 'NEXT':
                    self.is_running = False
                    Init_Menu.is_running = True
                    break

            elif not lm_list:
                self.up_flag = True
                self.down_flag = True
                self.forward_flag = True
                self.backward_flag = True
                self.play_stop_flag = True
                self.full_normal_flag = True


            # 프레임 화면에 출력
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # BGR을 RGB로 변환
            h, w, ch = rgb_frame.shape
            bytes_per_line = ch * w 
            q_img = QImage(rgb_frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
            q_pixmap = QPixmap.fromImage(q_img)
            self.Webcam_label2.setPixmap(q_pixmap) 

        if not self.is_running:
            # while문은 다음 화면으로 넘어갈때만 멈춘다.
            self.hide()

    def run_server(self):
        if self.server is None:
            self.server = Server(9000)
            self.user_list.append('admin')
            self.user_list_view()
            self.text_network_view1.append('네트워크 : 서버 시작.... 클라이언트 접속 대기중')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)
            self.server.run(self.server_recv_data)

     # 클라 -> 서버 메시지 수신했을 때
    def server_recv_data(self, sock, msg):
        tag, data = msg.split('@', 1)

        if tag == PacketTag.Login.value:
            self.text_network_view1.append(f'수신 메시지 : {msg}')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)
            self.user_list.append(data)
            self.user_list_view()
            self.ret = Control.login_ack(data, self.user_list, self.server)
            self.text_network_view1.append(f'송신 메시지 : {self.ret}') 
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)
            
        elif tag == PacketTag.Logout.value:
            self.text_network_view1.append(f'수신 메시지 : {msg}')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)
            self.user_list.remove(data)
            self.user_list_view()
            self.ret = Control.logout_ack(data, self.user_list, self.server)
            self.text_network_view1.append(f'송신 메시지 : {self.ret}') 
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)
            
        elif tag == PacketTag.Shortmessage.value:
            self.text_network_view1.append(f'수신 메시지 : {msg}')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)
            name, msg = data.split('#', 1)
            self.ret = Control.short_message_ack(name, msg, self.server)
            self.text_network_view1.append(f'송신 메시지 : {self.ret}') 
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

        elif tag == PacketTag.Sendbyte.value:
            self.text_network_view1.append(f'수신 메시지 : {tag}@bytes')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)
            recv_screen_thread = threading.Thread(target=self.recv_screen, args=(data,))
            recv_screen_thread.daemon = True
            recv_screen_thread.start()
        
        elif tag == PacketTag.Sendfile.value:
            filename, file_data = data.split('#', 1) 
            self.text_network_view1.append(f'수신 메시지 : {tag}@{filename}')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

            time.sleep(5)
            self.recv_file(filename, file_data)

        else:
            self.text_network_view1.append(f'모르는 메시지 수신 : {tag}')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

    # 접속자 리스트 갱신
    def user_list_view(self):
        self.person_listWidget1.clear()
        for user in self.user_list:
            self.person_listWidget1.addItem(user)

    def screen_share_start(self):
        if self.screen_share:
            self.screen_share = False
            share_thread = threading.Thread(target=self.share_screen)
            share_thread.daemon = True
            share_thread.start()

    def screen_share_stop(self):
        if not self.screen_share:
            self.screen_share = True
            self.text_network_view1.append('네트워크 : 화면공유 종료')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

            # 화면공유 종료 패킷을 클라이언트에 전송
            ret = Control.send_bytes_break_ack(self.server)
            self.text_network_view1.append(f'메시지 송신 : {ret}') 
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

        else:
            self.text_network_view1.append('네트워크 : 화면 공유 중이 아닙니다 (화면공유종료 감지)')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

    def share_screen(self):
        if self.requset_screen:
            self.text_network_view1.append('네트워크 : 화면 공유 시작')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)
            while not self.screen_share:

                # 모니터 화면 캡쳐
                image = pyautogui.screenshot()

                # 서버로 전송하기 위한 작업
                data = image.tobytes()
                compress_data = zlib.compress(data)
                length = len(data)

                # 화면 전송
                encoded_data = base64.b64encode(compress_data)
                pack = Packet.SendByte_ACK(encoded_data)
                self.server.send_all_data(pack)
                self.text_network_view1.append('네트워크 : 화면공유 중...')
                self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

                # self.Webcam_label에 보내는 이미지 출력
                # Bytes 데이터를 -> PIL의 Image 타입으로 변환 작업
                screen_image = Image.frombytes("RGB", (1920, 1080), data)

                # 이미지 크기를 960 x 540으로 조정
                width, height = 960, 540
                resized_image = screen_image.resize((width, height), Image.ANTIALIAS)

                # 이미지를 PyQt5의 QImage로 변환
                qimage = QImage(resized_image.tobytes(), width, height, QImage.Format_RGB888)
                pixmap = QPixmap.fromImage(qimage)

                # QLabel에 이미지를 표시
                self.Webcam_label.setPixmap(pixmap)

                time.sleep(0.1)
        else:
            self.text_view.append('네트워크 : 화면 수신 중 공유 불가능 (화면공유시작 감지)')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

    def request_screen_start(self):
        if self.screen_share:
            self.requset_screen = False
            # 만약 유저 리스트 위젯에서 선택을 안했다면...? ------- 2번째 사람의 이름으로 한다
            if not self.person_listWidget1.currentItem():
                if self.person_listWidget1.item(1):
                    item = self.person_listWidget1.item(1)
                    name = item.text()
                
                    # 그 이름을 클라이언트에게 보낸다.
                    ret = Control.request_screen_ack(name, self.server)
            else:
                item = self.person_listWidget1.currentItem()
                name = item.text()

                # 공유받을 화면을 띄움
                self.recv_screen.show()
                
                # 그 이름을 클라이언트에게 보낸다.
                ret = Control.request_screen_ack(name, self.server)

        else:
            self.text_view.append('네트워크 : 화면 공유중 수신 불가능')
            self.text_view.moveCursor(self.text_view.textCursor().End)

    def requset_screen_stop(self):
        if not self.requset_screen:
            self.requset_screen = True

            ret = Control.request_screen_stop_ack(self.server)
            self.text_network_view1.append(f'메시지 송신 : {ret}')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

        else:
            self.text_network_view1.append(f'네트워크 : 화면 수신중이 아닙니다 (화면수신중단 감지)')
            self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

    def recv_screen(self, img):
        
        while not self.requset_screen:
            # 데이터 검증작업
            if self.dataset is None:
                self.dataset = img
                data_img = self.dataset
                break
            else:
                # img 가 이전 데이터와 동일한 경우, 이전 데이터 삭제
                if img == self.dataset:
                    self.dataset = None
                    data_img = None
                    break
                # img가 이전 데이터와 다른 경우, data를 저장하고 이전 데이터 삭제
                else:
                    self.dataset = img
                    data_img = self.dataset

                    # 실제 이미지 데이터 -> UI 출력 파트
                    data = img.encode('utf-8')
                    decoded_data = base64.b64decode(data)
                    img_data = zlib.decompress(decoded_data)

                    # 데이터를 UI에 추가하거나 갱신
                    self.update_screen(img_data)
                    break

    def update_screen(self, img_data):
        # Bytes 데이터를 -> PIL의 Image 타입으로 변환 작업
        screen_image = Image.frombytes("RGB", (1920, 1080), img_data)

        # 이미지 크기를 1600 x 900으로 조정
        width, height = 960, 540
        resized_image = screen_image.resize((width, height), Image.ANTIALIAS)

        # 이미지를 PyQt5의 QImage로 변환
        qimage = QImage(resized_image.tobytes(), width, height, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(qimage)

        # QLabel에 이미지를 표시
        self.Webcam_label.setPixmap(pixmap)

    # 파일 선택 ( 파일 리스트 위젯에 파일 추가 )
    def select_file(self): 
        file_path, _ = QFileDialog.getOpenFileName(self, "파일 선택")
        # 선택된 파일을 지정된 폴더 ( C:\Users\user\Desktop\다운로드 )에 이동 시키기
        Download_path = r'C:\Users\user\Desktop\다운로드'

        # 0. 경로가 존재하지 않을 경우 폴더 생성
        if not os.path.exists(Download_path):
            os.makedirs(Download_path)

        # file_path -> 파일을 Download_path에 복사시킴 
        shutil.copy(file_path, Download_path)
        
        # 파일 리스트뷰 로드
        self.file_widget_Item_add()

    def open_folder(self):
        self.folder = False

        folder_path = r"C:\Users\user\Desktop\다운로드"

        try:
            subprocess.Popen(["explorer", folder_path])
        except Exception as e:
            print("폴더를 열 수 없습니다:", e)

    def file_send(self):
        self.send = False

        self.text_network_view1.append('파일 전송')
        send_file_path = r'C:\Users\user\Desktop\다운로드'
        selected_file = self.file_listView1.currentItem()

        if selected_file:
            file_name = selected_file.text()
            file_path = send_file_path + f'\{file_name}'

            if os.path.exists(file_path) and os.path.isfile(file_path):
                # 1. 파일을 바이트로 변환하기
                with open(file_path, 'rb') as file:
                    file_data = file.read()

                # 2. 바이트 데이터를 문자열로 변환하기
                based_file_data = base64.b64encode(file_data)
                file_name = os.path.basename(file_path)

                # 파일 패킷 생성 및 전송
                pack = Packet.SendFile_ACK(file_name, based_file_data)
                self.server.send_all_data(pack)
                        

                # 전송 로그
                tag, data = pack.split('@', 1)
                filename, filedata = data.split('#', 1)

                self.text_network_view1.append(f'송신 메시지 : {tag}@{filename}')
                self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)
                
            else:
                self.text_network_view1.append('에러 : 폴더에 파일이 없습니다.')
                self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)
        else:
            # 파일을 선택 안했을 때 리스트 위젯의 첫번째 파일을 보낸다.
            file = self.file_listView1.item(0)
            file_name = file.text()
            file_path = send_file_path + f'\{file_name}'

            if os.path.exists(file_path) and os.path.isfile(file_path):
                # 1. 파일을 바이트로 변환하기
                with open(file_path, 'rb') as file:
                    file_data = file.read()

                # 2. 바이트 데이터를 문자열로 변환하기
                based_file_data = base64.b64encode(file_data)
                file_name = os.path.basename(file_path)

                # 파일 패킷 생성 및 전송
                pack = Packet.SendFile_ACK(file_name, based_file_data)
                self.server.send_all_data(pack)
                

                # 전송 로그
                tag, data = pack.split('@', 1)
                filename, filedata = data.split('#', 1)

                self.text_network_view1.append(f'송신 메시지 : {tag}@{filename}')
                self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

                
            else:
                self.text_network_view1.append('에러 : 폴더에 파일이 없습니다.')
                self.text_network_view1.moveCursor(self.text_network_view1.textCursor().End)

    # 파일 받았을 때
    def recv_file(self, file_name, file_data):
        try:
            download_path = r'C:\Users\user\Desktop\다운로드'  # 파일 다운로드 경로

            # 0. 경로가 존재하지 않을 경우 폴더 생성
            if not os.path.exists(download_path):
                os.makedirs(download_path)

            # 1. base64 디코딩
            decoded_filedata = base64.b64decode(file_data)

            # 2. 파일 저장
            save_path = os.path.join(download_path, file_name)

            with open(save_path, 'wb') as file:
                file.write(decoded_filedata)

            self.text_network_view1.append(f'{file_name} 저장 성공')

            # 3. 받은 파일을 파일 리스트 위젯의 아이템에 넣기
            self.file_widget_Item_add()

        except Exception as e:
            print(f'파일 수신중 오류 발생 : {e}')

    # 프로그램이 시작 되었을 때 다운로드 폴더의 파일들이 위젯에 들어감
    def file_widget_Item_add(self):
        self.file_listView1.clear()

        path = r'C:\Users\user\Desktop\다운로드'

        # 0. 경로가 존재하지 않을 경우 폴더 생성
        if not os.path.exists(path):
            os.makedirs(path)

        for filename in os.listdir(path):
            file_path = os.path.join(path, filename)
            if os.path.isfile(file_path):
                item = QListWidgetItem(filename)
                self.file_listView1.addItem(item)



if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Init_Menu()
    window.show()
    sys.exit(app.exec_())